package ec.edu.udla.LocalCache;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocalCacheApplication {

	public static void main(String[] args) {
		SpringApplication.run(LocalCacheApplication.class, args);
	}

}
