package ec.edu.udla.LocalCache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocalCacheApplicationTests {

	@Test
	void contextLoads() {
	}

}
